# GAM-model
The effect of greenhouse gases and black carbon aerosols on global warming.

We have analyzed data of the whole world of greenhouse gases, black carbon aerosols and temperature using both the univariate and multivariate generalized additive model using R. Also note that the latitude and longitude of each country is in the csv file named "countries.csv". 
